import java.util.Scanner;

public class ConstructionTester
{
    public static void main(String[] args)
    {
        // Start here!
         Scanner stdin = new Scanner(System.in);
      
       System.out.println("Enter the sales tax rate:");
double taxes = stdin.nextDouble();
Construction mine = new Construction(8, 11, taxes);
System.out.println("How many boards do you need?");
int numBoards = stdin.nextInt();

System.out.println("How many windows do you need?");
int numWindows = stdin.nextInt();
  

double total = mine.lumberCost(numBoards) + mine.windowCost(numWindows);

double grandTotal = mine.grandTotal(total);
  
// Printing result
System.out.println("Total: " + total);
System.out.println("Grand Total: " + grandTotal);
    }
}