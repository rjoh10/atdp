public class CoinTester
{
    public static void main(String[] args) {

       //Create your program here
     
                    
     Coins c1 = new Coins (4, 3, 2, 1);
     c1.bankValue();

     c1.addQuarter();

     c1.addQuarter();

     c1.addDime();

     c1.addDime();

     c1.addPenny();

     c1.bankCount();

     c1.bankValue();

     System.out.println(c1);
       
    }
}