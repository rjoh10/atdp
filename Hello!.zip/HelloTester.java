import java.util.Scanner;

public class HelloTester
{
   public static void main(String[] args) {

Scanner input = new Scanner(System.in);

System.out.println("Please enter your name: ");

String name = input.nextLine();

Hello helloObj = new Hello(name);
helloObj.english();

System.out.println(helloObj);
helloObj.french();

System.out.println(helloObj);
helloObj.spanish();
System.out.println(helloObj);
}
}