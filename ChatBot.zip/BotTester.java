import java.util.Scanner;

public class BotTester
{
    public static void main(String[] args) {

        //Put your code here
          Scanner input = new Scanner(System.in);
        String name;
        
        System.out.println("Hello. What is your name?");
        name = input.nextLine();
        
        Bot bot = new Bot(name);
        
        bot.greeting();
        bot.help();
        System.out.println("What's the weather like?");
        bot.weather();
        System.out.println("How many feet in a mile?");
        bot.feetInMile();
        bot.goodbye();
    }
}