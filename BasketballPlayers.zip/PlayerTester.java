public class PlayerTester
{
    public static void main(String[] args) {
       
       //Start here
      BasketballPlayer lebronJames= new BasketballPlayer( "Lebron James", "Lakers");
    //  addGame();
      
      System.out.println("Lebron James Stats: ");
      lebronJames.addGame(26,13);
        lebronJames.addGame(27,13);
          lebronJames.addGame(26,13);
            lebronJames.addGame(27,13);
      lebronJames.printPPG();
      lebronJames.printAPG();
    
      System.out.println(lebronJames);
       System.out.println();
      
      BasketballPlayer michaelJordan=new BasketballPlayer ("Michael Jordan");
   //  michaelJordan.addGame()
    System.out.println("Michael Jordan Stats: ");
      michaelJordan.addGame(31,9);
        michaelJordan.addGame(30,8);
          michaelJordan.addGame(31,8);
            michaelJordan.addGame(30,8);
      michaelJordan.printPPG();
      michaelJordan.printAPG();
    
      System.out.println(michaelJordan);
      
       
    }
}