import java.util.Scanner;

public class CalculatorTester
{
    public static void main(String[] args)
    {
        // Put your code here
        // A good place to start is to
        // create comments like the last exercise
        // to remind yourself what you need to do
        
        //To get started, create a new Calculator object
        Scanner scan=new Scanner(System.in);
       double x=scan.nextDouble();
       double y=scan.nextDouble();

       // creating an object variable of class Calculator
       Calculator cal=new Calculator();
       cal.sum(x,y); // calling sum method in Calculator class
       System.out.println(); // for new line
       cal.subtract(x,y);
       System.out.println();
       cal.multiply(x,y);
       System.out.println();
       cal.divide(x,y);
       System.out.println();
    }
}