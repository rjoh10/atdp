import java.util.Scanner;

public class Bot2Tester
{
    public static void main(String[] args) {

       //Start Here!
       Scanner input = new Scanner(System.in);
// asking user to enter is name
System.out.print("Hello. What is your name? ");
// calling nextLine method in Scanner for get user name, which returns string
String name = input.nextLine();
// creating Bot2 object by the calling the constructor with name as parameter
Bot2 the = new Bot2(name);
// calling the gretting method of Bot2 object
the.greeting();
// asking user to enter his favorite animal
System.out.println("What is your favorite animal?");
String yourAnimal = input.nextLine();
// printing new line as per required output
System.out.println();
// calling the favoriteAnimal in Bot2 object method with your animal as parameter
the.favoriteAnimal(yourAnimal);
// asking user to enter his location
System.out.println("Where do you live?");
String location = input.nextLine();
// calling the home method in Bot2 object with location as parameter
the.home(location);
// asking user to enter his favorite number
System.out.println("What is your favorite number?");
// calling nextInt method in Scanner object and storing in num variable
int num = input.nextInt();
// calling favoriteAnimal method in Bot2 object with num as parameter
the.favoriteNumber(num);
the.goodbye();
    }
}