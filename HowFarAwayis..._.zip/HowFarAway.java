import java.util.Scanner;

public class HowFarAway 
{
    public static void main(String[] args)
    {
       //    HowFarAway the = new HowFarAway();
      Scanner scanner = new Scanner(System.in);

    System.out.print("Enter the latitude of the starting location: ");

    double lat1 = scanner.nextDouble();

    System.out.println();

    System.out.print("Enter the longitude of the starting location: ");

    double long1 = scanner.nextDouble();

    System.out.println();

    System.out.print("Enter the latitude of the ending location: ");

    double lat2 = scanner.nextDouble();

    System.out.println();

    System.out.print("Enter the longitude of the ending location: ");

    double long2 = scanner.nextDouble();

    System.out.println();



GeoLocation loc1 = new GeoLocation(lat1, long1);   
       GeoLocation loc2 = new GeoLocation(lat2, long2);   
       double d1 = loc1.distanceFrom(loc2);    
       
// printing the distance in miles
  System.out.println("The distance is "+d1 + " miles.");

    System.out.println();
    }
}