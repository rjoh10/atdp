public class GamesTester
{
    public static void main(String[] args)
    {
        NumberGames game = new NumberGames(3);
       // System.out.println(game);
         double d1;
         double square;
        // Double the number
        // Print it out
      d1=game.doubleNumber();
                System.out.println(d1); 


        
        // Square the number
        // Print it out
         square=game.squareNumber();   
                System.out.println(square);
                
        // Double the number again
        // Print it out
        d1=game.doubleNumber();                
                System.out.println(d1);   
        // Get the number and store the value
        // Print it out to see that getNumber does
        // not modify the number
 System.out.println(game.getNumber()); 
    }
}