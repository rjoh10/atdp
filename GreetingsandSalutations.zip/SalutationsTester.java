import java.util.Scanner;
public class SalutationsTester
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        String name;
        
        System.out.print("Enter your name: ");
        name = input.nextLine();
        System.out.println("");
        
        Salutations salute = new Salutations(name);
        
        System.out.println("Address Letter:");
        salute.addressLetter();
        System.out.println("");
        
        System.out.println("Sign Letter:");
        salute.signLetter();
        System.out.println("");
        
        System.out.println("Address Memo:");
        salute.addressMemo();
        System.out.println("");
        
        System.out.println("Sign Memo:");
        salute.signMemo();
    }
}