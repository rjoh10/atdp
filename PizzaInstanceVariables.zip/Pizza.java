public class Pizza
{
    // Add your instance variables here
    private String toppings;
        private String crust;
        private String cheese;  private String color; 
   
}