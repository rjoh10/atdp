public class WebsiteTester
{
    public static void main(String[] args)
    {
        Website weird = new Website() ;
        Website goodschool = new Website("goodSchool","edu") ;
        Website codehs = new Website("codehs","com",1000000) ;
        
        System.out.println(weird);
        System.out.println(goodschool);
         System.out.println(codehs);
    }
}