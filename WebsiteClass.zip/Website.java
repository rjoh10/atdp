public class Website
{
    // Put your code here
    
    String domain;
    String topLevelDomain;
    int numUsers;
    
    public Website()
    {
        domain = "";
        topLevelDomain = "com";
        numUsers = 0;
    };
    
    
    
  public Website(String mydomain, String mytopLevelDomain)
  {
      domain = mydomain;
      topLevelDomain = mytopLevelDomain;
      numUsers = 0;
  };
    
 public Website(String mydomain, String mytopLevelDomain, int mynumUsers)
  {
      domain = mydomain;
      topLevelDomain = mytopLevelDomain;
      numUsers = mynumUsers;
  };
    
    
    
    
    
    // String representation for printing
    // Do not modify this method
    public String toString()
    {
        String res =  "https://www." + domain + "." + topLevelDomain;
        res += " has " + numUsers + " users";
        
        return res;
    }
}